DROP TABLE IF EXISTS item;

CREATE TABLE employee  (
    first_name VARCHAR(40),
    last_name VARCHAR(40),
    company_name VARCHAR(40),
    address VARCHAR(40),
    city VARCHAR(40),
    county VARCHAR(40),
    state VARCHAR(40),
    zip VARCHAR(10)
);