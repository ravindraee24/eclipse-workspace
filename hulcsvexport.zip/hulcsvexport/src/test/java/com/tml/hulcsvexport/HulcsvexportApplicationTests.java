package com.tml.hulcsvexport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HulcsvexportApplicationTests {

	@Test
	void contextLoads() {
	}

}
